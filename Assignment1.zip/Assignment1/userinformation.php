<?php
$connection = mysqli_connect('localhost','root');
mysqli_select_db($connection,"20130386");
$User = $_POST['User'];
$Email= $_POST['Email'];
$Message= $_POST['Message'];

$query = "INSERT INTO   userinformation (User,Email,Message) VALUES ('$User','$Email','$Message')";

mysqli_query($connection,$query);
echo "Message Sent"


?>