<?php
$connection = mysqli_connect('localhost','root');
mysqli_select_db($connection,"20130386");
$firstname = $_POST['firstname'];
$email= $_POST['email'];
$experience= $_POST['experience'];

$query = "INSERT INTO   acceptedjobs (firstname,email, experience) VALUES ('$firstname','$email','$experience')";

mysqli_query($connection,$query);
echo "Request Sent to Accept The Job"


?>