
<?php
if ($_POST) {

  //database connection
  include 'config.php';
  try {


    $stmt = $con->prepare("INSERT INTO jobpost SET jobname=:jobname, jobdetails=:jobdetails, jobprice=:jobprice, jobimage=:jobimage");

    // posted values
    $jobname = htmlspecialchars(strip_tags($_POST['jobname']));
    $jobdetails = htmlspecialchars(strip_tags($_POST['jobdetails']));
    $jobprice = htmlspecialchars(strip_tags($_POST['jobprice']));

    //uploading Image

    $jobimage = !empty($_FILES["jobimage"]["name"])


      ? sha1_file($_FILES['jobimage']['tmp_name']) . "-" . basename($_FILES["jobimage"]["name"])
      : "";

    $jobimage = htmlspecialchars(strip_tags($jobimage));

    // bind the parameters
    $stmt->bindParam(':jobname', $jobname);
    $stmt->bindParam(':jobdetails', $jobdetails);
    $stmt->bindParam(':jobprice', $jobprice);
    $stmt->bindParam(':jobimage', $jobimage);

    if ($stmt->execute()) {
      echo "<div class='alert alert-success'>Record was saved.</div>";
      header('Location: post.php');
      if ($jobimage) {

        // sha1_file() function is used to make a unique file name
        $target_directory = "jobimages/";
        $target_file = $target_directory . $jobimage;
        $file_type = pathinfo($target_file, PATHINFO_EXTENSION);

        // error message is empty
        $file_upload_error_messages = "";
        $check = getimagesize($_FILES["jobimage"]["tmp_name"]);

        if ($check !== false) {
          // submitted file is an image
        } else {
          $file_upload_error_messages .= "<div>Submitted file is not an image.</div>";
        }
        $allowed_file_types = array("jpg", "jpeg", "png", "gif");
        if (!in_array($file_type, $allowed_file_types)) {
          $file_upload_error_messages .= "<div>Only JPG, JPEG, PNG, GIF files are allowed.</div>";
        }
        if (file_exists($target_file)) {
          $file_upload_error_messages .= "<div>Image already exists. Try to change file name.</div>";
        }
        if ($_FILES['jobimage']['size'] > (1024000)) {
          $file_upload_error_messages .= "<div>Image must be less than 1 MB in size.</div>";
        }
        if (!is_dir($target_directory)) {
          mkdir($target_directory, 0777, true);
        }
        if (empty($file_upload_error_messages)) {
          // it means there are no errors, so try to upload the file
          if (move_uploaded_file($_FILES["jobimage"]["tmp_name"], $target_file)) {
            // it means photo was uploaded
          } else {
            echo "<div class='alert alert-danger'>
          <div>Unable to upload photo.</div>
          <div>Update the record to upload photo.</div>
      </div>";
          }
        }

        // if $file_upload_error_messages is NOT empty
        else {
          // it means there are some errors, so show them to user
          echo "<div class='alert alert-danger'>
      <div>{$file_upload_error_messages}</div>
      <div>Update the record to upload photo.</div>
  </div>";
        }
      }
    } else {
      echo "<div class='alert alert-danger'>Unable to save record.</div>";
    }
  }

  // show error
  catch (Exception $exception) {
    echo "$exception";
  }
}
?>