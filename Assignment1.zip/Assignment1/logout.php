<?php
SESSION_START();
$_SESSION = array();
// Destroy the session.
session_destroy();
header('Location: index.php');
exit;
?>