<?php
    session_start();
    include('config.php');
    if (isset($_POST['register'])) {
        $username = $_POST['username'];
        $email = $_POST['email'];
        $password = $_POST['password'];



        $password_hash = password_hash($password, PASSWORD_BCRYPT);
        $query = $con->prepare("SELECT * FROM users WHERE email=:email");
        $query->bindParam("email", $email, PDO::PARAM_STR);
        $query->execute();
        if ($query->rowCount() > 0) {
            echo '<p class="error">The email address is already registered!</p>';
        }
        if ($query->rowCount() == 0) {
            $query = $con->prepare("INSERT INTO users(username,password,email) VALUES (:username,:password_hash,:email)");
            $query->bindParam("username", $username, PDO::PARAM_STR);
            $query->bindParam("password_hash", $password_hash, PDO::PARAM_STR);
            $query->bindParam("email", $email, PDO::PARAM_STR);
            $result = $query->execute();
            if ($result) {
                echo '<p class="success">Your registration was successful!</p>';
            } else {
                echo '<p class="error">Something went wrong!</p>';
            }
        }
    }
?>
<!DOCTYPE html>
<html>
<html lang="en">
<head>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP Jaspreet Website</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css"/>
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
    
</head>
<body>
    <section class="main">
        <nav>
            <a href="#" class="logo">
                <img src="images/Logo.png"/></a>
            <div class ="nav-links">
            <ul>
            
            <li><a href="jobsavailable.php" class=>Jobs Available</a></li>
            <li><a href="post.php" class=>Post</a></li>
            <li><a href="contact.php" class=>Contact us</a></li>
            </ul>

</div>
        </nav>
   
        <div class="login">
        <h1> Register to Tasker</h1>
        <form action ="register.php" method="POST" class="login-email">

       <div class="input-group">
           <input type="text" placeholder="Username" name="username" required/>
       </div>
       <div class="input-group">
           <input type="email" placeholder="email"name="email" required/>
       </div>
       <div class="input-group">
           <input type="password" placeholder="Password"name="password" required/>
           </div>
       <div class="input-group">
           <input type="confirm password" placeholder="Confirm Pasword"name="confirm password" required/>
       <div class="input-group">
           <button name = "register" class="btn">Register</button>
       </div>
       <p type="submit" class="login-register-text"> Have an Account?<a href="index.php">Login Here</a>.</p>
</div>
</form>
    </div>
    </section>
    <footer class="text-muted py-5">
  <div class="container">
    <p class="top">
      <a href="#">Back to top</a>
    </p>
    <p>Tasker is a not just any work site in here your dreams comes true u can choose to do whatever u want!!!!</p>
    
    <p class="mb-0">New to Tasker? <a href="register.php">Visit our Homepage and Register</a> or read abut what tasker is @ <a href="tasker.php">About</a>.</p>
  </div>
</footer>


    <script src="/docs/5.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

      
</body>
</html>

