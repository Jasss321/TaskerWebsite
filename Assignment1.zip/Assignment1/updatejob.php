<!DOCTYPE html>
<html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP Jaspreet Website</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">

</head>

<body>
    <section class="main">
        <nav>
            <a href="#" class="logo">
                <img src="images/Logo.png" /></a>
            <div class="nav-links">
                <ul>
                    
                    <li><a href="logout.php">Logout</a></li>
                    
                </ul>

            </div>
        </nav>
        <?php
        // get passed parameter value, in this case, the record ID
        // isset() is a PHP function used to verify if a value is there or not
        $jobid = isset($_GET['jobid']) ? $_GET['jobid'] : die('ERROR: Record ID not found.');

        //include database connection
        include 'config.php';

        // read current record's data
        try {
            // prepare select query
            $query = "SELECT jobid, jobname, jobdetails, jobprice FROM jobpost WHERE jobid = ? LIMIT 0,1";
            $stmt = $con->prepare($query);

            // this is the first question mark
            $stmt->bindParam(1, $jobid);

            // execute our query
            $stmt->execute();

            // store retrieved row to a variable
            $row = $stmt->fetch(PDO::FETCH_ASSOC);

            // values to fill up our form
            $jobname = $row['jobname'];
            $jobdetails = $row['jobdetails'];
            $jobprice = $row['jobprice'];
        }

        // show error
        catch (PDOException $exception) {
            die('ERROR: ' . $exception->getMessage());
        }
        ?>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"] . "?jobid={$jobid}"); ?>" method="post">
            <table class='table table-hover table-responsive table-bordered'>
                <tr>
                    <td>Job Name</td>
                    <td><input type='text' name='jobname' value="<?php echo htmlspecialchars($jobname, ENT_QUOTES); ?>" class='form-control' /></td>
                </tr>
                <tr>
                    <td>Job Details</td>
                    <td><textarea name='jobdetails' class='form-control'><?php htmlspecialchars($jobdetails, ENT_QUOTES);  ?></textarea></td>
                </tr>
                <tr>
                    <td>Job Price</td>
                    <td><input type='text' name='jobprice' value="<?php echo  htmlspecialchars($jobprice, ENT_QUOTES); ?>" class='form-control' /></td>
                </tr>
                <tr>
                    <td></td>
                    <td>
                        <input type='submit' value='update' class='btn btn-primary' />
                        <a href='adminjobs.php' class='btn btn-danger'>Back to read Jobs</a>
                    </td>
                </tr>
            </table>
        </form>
        <?php

        // check if form was submitted
        if ($_POST) {

            try {

                // writing and update query

                $query = "UPDATE jobpost
                    SET jobname=:jobname, jobdetails=:jobdetails, jobprice=:jobprice
                    WHERE jobid = :jobid";

                // prepare query for excecution
                $stmt = $con->prepare($query);

                // posted values
                $jobname = htmlspecialchars(strip_tags($_POST['jobname']));
                $jobdetails = htmlspecialchars(strip_tags($_POST['jobdetails']));
                $jobprice = htmlspecialchars(strip_tags($_POST['jobprice']));

                // bind the parameters
                $stmt->bindParam(':jobname', $jobname);
                $stmt->bindParam(':jobdetails', $jobdetails);
                $stmt->bindParam(':jobprice', $jobprice);
                $stmt->bindParam(':jobid', $jobid);

                // Execute the query
                if ($stmt->execute()) {
                    echo "<div class='alert alert-success'>Record was updated.</div>";
                } else {
                    echo "<div class='alert alert-danger'>Unable to update record. Please try again.</div>";
                }
            }

            // show errors
            catch (PDOException $exception) {
                die('ERROR: ' . $exception->getMessage());
            }
        }
        ?>
        </main>

        <footer class="text-muted py-5">
            <div class="container">
                <p class="top">
                    <a href="#">Back to top</a>
                </p>
                <p>Tasker is a not just any work site in here your dreams comes true you can choose to do whatever you want!!!!</p>

                <p class="mb-0">New to Tasker? <a href="register.php">Visit our Homepage and Register</a> or read abut what tasker is @ <a href="tasker.php">About</a>.</p>
            </div>
        </footer>


        <script src="/docs/5.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>


</body>

</html>