
<!DOCTYPE html>
<html>

<head>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP Jaspreet Website Admin Page</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">

</head>

<body>
    <section class="main">
        <nav>
            <a href="#" class="logo">
                <img src="images/Logo.png" /></a>
            <section class="main">
                <div class="login">
                    <h1> Admin Page <h1>
                            <div class="login-form-input">
                                <form method="post" action="verify.php" class="login-email">
                                    <div class="input-group">
                                        <input type="adminname" name="adminname" placeholder="Adminname" required />
                                    </div>
                                    <div class="input-group">
                                        <input type="password" name="password" placeholder="Password" required>
                                    </div>
                                    <div class="input-group">
                                        <button type="submit" name="login" value="Sign in" class="btn">Admin login</button>
                                    </div>
                                </form>
                            </div>
                </div>
            </section>
            <footer class="text-muted py-5">
                <div class="container">
                    <p class="top">
                    </p>
                    <p>Tasker is a not just any work site in here your dreams comes true you can choose to do whatever you want!!!!</p>
                </div>
            </footer>
            <script src="/docs/5.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</body>

</html>
