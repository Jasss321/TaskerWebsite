<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
} else {
    // Show users the page!
}
?>
<!DOCTYPE html>
<html>
<html lang="en">

<head>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP Jaspreet Website</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">

</head>

<body>
    <section class="main">
        <nav>
            <a href="#" class="logo">
                <img src="images/Logo.png" /></a>
            <div class="nav-links">
                <ul>

                    <li><a href="jobsavailable.php" class=>Jobs Available</a></li>
                    <li><a href="post.php" class=>Post</a></li>
                    <li><a href="contact.php" class=>Contact us</a></li>
                    <li><a href="logout.php">Logout</a></li>
                    <li><a href="adminlogin.php" class=>Admin Login </a></li>
                </ul>

            </div>
        </nav>
        <?php
        // include database connection
        include 'config.php';

        $query = "SELECT jobid, jobname, jobdetails, jobprice, jobimage FROM jobpost";
        $stmt = $con->prepare($query);
        $stmt->execute();

        $num = $stmt->rowCount();

        //check if more than 0 record found
        if ($num > 0) {
        ?>
            <div class="container">
                <div class="row">
                    <?php
                    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                        extract($row);
                    ?>

                        <div class="card hovercard">
                            <div class="cardheader">
                                <div class="avatar">
                                    <img alt="" src="<?php echo $row['jobimage']; ?>">
                                </div>
                            </div>
                            <div class="card-body info">
                                <div class="title">
                                    <a href="#"><?php echo $row['jobid']; ?></a>

                                </div>
                                <a class="btn btn-primary btn-read btn-sm" href="readonejob.php?jobid=<?php echo $row['jobid']; ?>" class="btn btn-info m-r-1em">View Job In Full
                                    Details</a>
                                <div class="desc"><?php echo $row['jobname']; ?></div>
                                <div class="desc"><?php echo $row['jobdetails']; ?></div>
                                <div class="desc"><?php echo $row['jobprice']; ?></div>

                            </div>
                            <div class="card-footer bottom">

                                </a>
                            </div>
                        </div>
                    <?php
                    }
                    ?>
                <?php
                //


                //
                /*echo "<a href='update.php?jobid={$jobid}' class='btn btn-primary m-r-1em'>Edit</a>";

                            //
                            echo "<a href='#' onclick='delete_user({$jobid});' class='btn btn-danger'>Delete</a>";*/
                echo "</td>";
                echo "
                    </tr>";



                echo "</tbody>";
                echo "
        </table>";
                // link to create record form
                echo "<a href='post.php' class='btn btn-primary m-b-1em'>Create New Job</a>";
            } else {
                echo "<div class='alert alert-danger'>No records found.</div>";
            }

                ?>
                </main>

                <footer class="text-muted py-5">
                    <div class="container">
                        <p class="top">
                            <a href="#">Back to top</a>
                        </p>
                        <p>Tasker is a not just any work site in here your dreams comes true you can choose to do
                            whatever you
                            want!!!!</p>

                        <p class="mb-0">New to Tasker? <a href="register.php">Visit our Homepage and Register</a> or
                            read abut
                            what tasker is @ <a href="tasker.php">About</a>.</p>
                    </div>
                </footer>


                <script src="/docs/5.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous">
                </script>



</body>

</html>