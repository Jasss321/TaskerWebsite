<?php

session_start();
if (isset($_SESSION['login'])) {
    $_SESSION = $_SESSION['login'];
    die();
}
?>
<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP Jaspreet Website</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">

</head>

<body>
    <section class="main">
        <nav>
            <a href="#" class="logo">
                <img src="images/Logo.png" /></a>
            <div class="nav-links">
                <ul>

                    <li><a href="logout.php">Logout</a></li>
                </ul>

            </div>
        </nav>
        <?php
        // include database connection
        include 'config.php';

        $query = "SELECT jobid, jobname, jobdetails, jobprice, jobimage FROM jobpost";
        $stmt = $con->prepare($query);
        $stmt->execute();

        $num = $stmt->rowCount();

        //check if more than 0 record found
        if ($num > 0) {



            // data from database will be here
            echo "<table class='table table-hover table-responsive table-bordered'>";

            //creating our table heading
            echo "<h1> Admin Page for Updating and Deleting the Jobs!!!!!!!! <h1>";
            echo "</br>";

            echo "<tr>
        <th>jobid</th>
        <th>jobname</th>
        <th>jobdetails</th>
        <th>jobprice</th>
        <th>Action</th>
    </tr>";


            // table body will be here
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                // extract row
                // this will make $row['firstname'] to
                // just $firstname only
                extract($row);

                // creating new table row per record
                echo "<tr>
            <td>{$jobid}</td>
            <td>{$jobname}</td>
            <td>{$jobdetails}</td>
            <td>{$jobprice}</td>
            <td>";


                // we will use this links on next part of this post
                echo "<a href='updatejob.php?jobid={$jobid}' class='btn btn-primary m-r-1em'>Edit</a>";

                // we will use this links on next part of this post
                echo "<a href='#' onclick='delete_user({$jobid});'  class='btn btn-danger'>Delete</a>";
                echo "</td>";
                echo "</tr>";
            }

            // end table
            echo "</table>";
        }

        // if no records found
        else {
            echo "<div class='alert alert-danger'>No records found.</div>";
        }
        ?>
        </main>

        <footer class="text-muted py-5">
            <div class="container">
                <p class="top">
                    <a href="#">Back to top</a>
                </p>
                <p>Tasker is a not just any work site in here your dreams comes true you can choose to do
                    whatever you
                    want!!!!</p>

                <p class="mb-0">New to Tasker? <a href="register.php">Visit our Homepage and Register</a> or
                    read abut
                    what tasker is @ <a href="tasker.php">About</a>.</p>
            </div>
        </footer>

        <?php
        $action = isset($_GET['action']) ? $_GET['action'] : "";

        // if it was redirected from delete.php
        if ($action == 'deleted') {
            echo "<div class='alert alert-success'>Job was deleted.</div>";
        }
        ?>
        <script type='text/javascript'>
            // confirm record deletion
            function delete_user(jobid) {

                var answer = confirm('Are you sure you want to delete the Job?');
                if (answer) {
                    // if user clicked ok,
                    // 
                    window.location = 'delete.php?jobid=' + jobid;
                }
            }
        </script>

        <script src="/docs/5.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous">
        </script>
        <script>
            src = "./jobdetails.js"
        </script>


</body>

</html>