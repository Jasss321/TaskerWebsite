<!DOCTYPE html>
<html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP Jaspreet Website</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">

</head>

<body>
    <section class="main">
        <nav>
            <a href="#" class="logo">
                <img src="images/Logo.png" /></a>
            <div class="nav-links">
                <ul>
                    <li><a href="jobsavailable.php" class=>Jobs Available</a></li>
                    <li><a href="post.php" class=>Post</a></li>
                    <li><a href="contact.php" class=>Contact us</a></li>
                    <li><a href="logout.php">Logout</a></li>
                    <li><a href="adminlogin.php" class=>Admin Login </a></li>
                </ul>

            </div>
        </nav>
        <?php

        $jobid = isset($_GET['jobid']) ? $_GET['jobid'] : die('ERROR: Record ID not found.');

        include 'config.php';

        try {
            // prepare select query
            $query = "SELECT jobid, jobname, jobdetails, jobprice, jobimage FROM jobpost WHERE jobid = ? LIMIT 0,1";
            $stmt = $con->prepare($query);

            $stmt->bindParam(1, $jobid);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);

            $jobname = $row['jobname'];
            $jobdetails = $row['jobdetails'];
            $jobprice = $row['jobprice'];
            $jobimage = htmlspecialchars($row['jobimage'], ENT_QUOTES);
        }

        // show error
        catch (PDOException $exception) {
            die('ERROR: ' . $exception->getMessage());
        }
        ?>
        <table class='table table-hover table-responsive table-bordered'>
            <tr>
                <td>Job Name</td>
                <td><?php echo htmlspecialchars($jobname, ENT_QUOTES);  ?></td>
            </tr>
            <tr>
                <td>Job Details</td>
                <td><?php echo htmlspecialchars($jobdetails, ENT_QUOTES);  ?></td>
            </tr>
            <tr>
                <td>Job Price</td>
                <td><?php echo htmlspecialchars($jobprice, ENT_QUOTES);  ?></td>
            </tr>
            <tr>
                <td>Image</td>
                <td>
                    <?php echo $jobimage ? "<img src='jobimages/{$jobimage}' style='width:300px;' />" : "No image found.";  ?>
                </td>
            </tr>
            <tr>
                <td></td>
                <td>
                    <a href='jobsavailable.php' class='btn btn-danger'>Back to read Jobs</a>
                    <a href='  acceptjob.php' class='btn btn-primary m-b-1em'>Accept Job</a>
                </td>
            </tr>
        </table>
        </main>
</body>

</html>
<footer class="text-muted py-5">
    <div class="container">
        <p class="top">
            <a href="#">Back to top</a>
        </p>
        <p>Tasker is a not just any work site in here your dreams comes true you can choose to do whatever you want!!!!</p>

        <p class="mb-0">New to Tasker? <a href="register.php">Visit our Homepage and Register</a> or read abut what tasker is @ <a href="tasker.php">About</a>.</p>
    </div>
</footer>


<script src="/docs/5.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>


</body>

</html>