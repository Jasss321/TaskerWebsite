<?php
    session_start();
    if(!isset($_SESSION['user_id'])){
        header('Location: index.php');
        exit;
    } else {
        // Show users the page!
    }
?>
<?php
if ($_POST) {

  //database connection
  include 'config.php';
  try {


    $stmt = $con->prepare("INSERT INTO jobpost SET jobname=:jobname, jobdetails=:jobdetails, jobprice=:jobprice, jobimage=:jobimage");

    // posted values
    $jobname = htmlspecialchars(strip_tags($_POST['jobname']));
    $jobdetails = htmlspecialchars(strip_tags($_POST['jobdetails']));
    $jobprice = htmlspecialchars(strip_tags($_POST['jobprice']));

    //uploading Image

    $jobimage = !empty($_FILES["jobimage"]["name"])


      ? sha1_file($_FILES['jobimage']['tmp_name']) . "-" . basename($_FILES["jobimage"]["name"])
      : "";

    $jobimage = htmlspecialchars(strip_tags($jobimage));

    // bind the parameters
    $stmt->bindParam(':jobname', $jobname);
    $stmt->bindParam(':jobdetails', $jobdetails);
    $stmt->bindParam(':jobprice', $jobprice);
    $stmt->bindParam(':jobimage', $jobimage);

    if ($stmt->execute()) {
      echo "<div class='alert alert-success'>Record was saved.</div>";
      header('Location: post.php');
      if ($jobimage) {

        // sha1_file() function is used to make a unique file name
        $target_directory = "jobimages/";
        $target_file = $target_directory . $jobimage;
        $file_type = pathinfo($target_file, PATHINFO_EXTENSION);

        // error message is empty
        $file_upload_error_messages = "";
        $check = getimagesize($_FILES["jobimage"]["tmp_name"]);

        if ($check !== false) {
          // submitted file is an image
        } else {
          $file_upload_error_messages .= "<div>Submitted file is not an image.</div>";
        }
        $allowed_file_types = array("jpg", "jpeg", "png", "gif");
        if (!in_array($file_type, $allowed_file_types)) {
          $file_upload_error_messages .= "<div>Only JPG, JPEG, PNG, GIF files are allowed.</div>";
        }
        if (file_exists($target_file)) {
          $file_upload_error_messages .= "<div>Image already exists. Try to change file name.</div>";
        }
        if ($_FILES['jobimage']['size'] > (1024000)) {
          $file_upload_error_messages .= "<div>Image must be less than 1 MB in size.</div>";
        }
        if (!is_dir($target_directory)) {
          mkdir($target_directory, 0777, true);
        }
        if (empty($file_upload_error_messages)) {
          // it means there are no errors, so try to upload the file
          if (move_uploaded_file($_FILES["jobimage"]["tmp_name"], $target_file)) {
            // it means photo was uploaded
          } else {
            echo "<div class='alert alert-danger'>
          <div>Unable to upload photo.</div>
          <div>Update the record to upload photo.</div>
      </div>";
          }
        }

        // if $file_upload_error_messages is NOT empty
        else {
          // it means there are some errors, so show them to user
          echo "<div class='alert alert-danger'>
      <div>{$file_upload_error_messages}</div>
      <div>Update the record to upload photo.</div>
  </div>";
        }
      }
    } else {
      echo "<div class='alert alert-danger'>Unable to save record.</div>";
    }
  }

  // show error
  catch (Exception $exception) {
    echo "$exception";
  }
}
?>
<!DOCTYPE html>
<html>
<html lang="en">
<head>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>PHP Jaspreet Website</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  <link rel="stylesheet" href="css/style.css" />
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">

</head>

<body>
  <section class="main">
    <nav>
      <a href="#" class="logo">
        <img src="images/Logo.png" /></a>
      <div class="nav-links">
        <ul>

          <li><a href="jobsavailable.php" class=>Jobs Available</a></li>
          <li><a href="post.php" class=>Post</a></li>
          <li><a href="contact.php" class=>Contact us</a></li>
          <li><a href="logout.php">Logout</a></li>
          <li><a href="adminlogin.php" class=>Admin Login </a></li>
        </ul>

      </div>
    </nav>
    <div class="contact">
      <div class="contact-heading">
        <div class="post-form-input">
          <h1>Post Jobs</h1>
          <form action="postform.php" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" enctype="multipart/form-data">
            <input type="Text" id="jobname" name="jobname" placeholder="Job Name" />
            <input type="text" id="jobprice" name="jobprice" placeholder="Job Price" />
            <textarea name="jobdetails" id="jobdetails" placeholder="Please Enter the details about the job.."></textarea>
            <div class="form-group">
              </td>
              </tr>
            </div>
            <p>Please Only Upload .jpeg Images to meet out Image uploade Criteria!!</p>
            <input id="jobimage" type="file" class="form-control" name="jobimage" />
            <button name="upload" class="main-btn contact-btn" type="submit">Add Job</button>
        </div>
      </div>
    </div>
    </form>
    </div>
    </div>
  </section>
</body>

</html>
<footer class="text-muted py-5">
  <div class="container">
    <p class="top">
      <a href="#">Back to top</a>
    </p>
    <p>Tasker is a not just any work site in here your dreams comes true you can choose to do whatever you want!!!!</p>

    <p class="mb-0">New to Tasker? <a href="register.php">Visit our Homepage and Register</a> or read abut what tasker is @ <a href="tasker.php">About</a>.</p>
  </div>
</footer>


<script src="/docs/5.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

<?php
// remove all session variables
session_unset();

// destroy the session
session_destroy();
?>
</body>

</html>
<?php
?>